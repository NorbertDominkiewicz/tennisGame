package entity;

import main.GameBoard;
import main.JoyStick;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Player extends Entity{
    Color playerColor;
    GameBoard gameBoard;
    JoyStick joyStick;
    Image playerImg;
    public Player(GameBoard gameBoard, JoyStick joyStick, Color playerColor, int x, int y, String direction){
        this.gameBoard = gameBoard;
        this.joyStick = joyStick;
        this.playerColor = playerColor;
        speed = 5;
        setPosition(x,y);
        setImage(direction);
    }
    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
    }
    public void setImage(String direction){
        if(direction == "right"){
            try{
                playerImg = ImageIO.read(new File("src/resources/playerRight.png"));
            } catch (IOException e){
                System.out.println(e.getMessage());
            }
        }
        if(direction == "left"){
            try{
                playerImg = ImageIO.read(new File("src/resources/playerLeft.png"));
            } catch (IOException e){
                System.out.println(e.getMessage());
            }
        }
    }
    public void update(){
        if(joyStick.up){
            y -= speed;
        }
        if(joyStick.down){
            y += speed;
        }
        if(joyStick.left){
            x -= speed;
        }
        if(joyStick.right){
            x += speed;
        }
    }
    public void draw(Graphics2D g2d){
        g2d.setColor(playerColor);
        g2d.drawImage(playerImg,x,y,70,70,null);
    }
}
