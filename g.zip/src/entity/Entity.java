package entity;

public class Entity {
    boolean collision = false;
    int x,y;
    int speed;
}
