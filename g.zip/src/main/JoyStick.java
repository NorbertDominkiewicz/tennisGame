package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class JoyStick implements KeyListener {
    int[] moveCodes;
    public boolean up,down,left,right= false;
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == moveCodes[0]){
            up = true;
        }
        if(e.getKeyCode() == moveCodes[1]){
            down = true;
        }
        if(e.getKeyCode() == moveCodes[2]){
            left = true;
        }
        if(e.getKeyCode() == moveCodes[3]){
            right = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode() == moveCodes[0]){
            up = false;
        }
        if(e.getKeyCode() == moveCodes[1]){
            down = false;
        }
        if(e.getKeyCode() == moveCodes[2]){
            left = false;
        }
        if(e.getKeyCode() == moveCodes[3]){
            right = false;
        }
    }
    JoyStick(int[] moveCodes){
        this.moveCodes = moveCodes;
    }
}
