package main;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Game extends JFrame {
    GameBoard gameBoard;
    Game(){
        gameBoard = new GameBoard();
        gameBoard.startGame();
        setResizable(false);
        setSize(new Dimension(gameBoard.screenWidth,gameBoard.screenHeight));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(gameBoard);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String[]args){
        Game game= new Game();
    }
}
