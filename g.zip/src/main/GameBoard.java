package main;

import entity.Player;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class GameBoard extends JPanel implements Runnable {
    final int screenWidth = 1200;
    final int screenHeight = 600;
    final int FPS = 60;

    Thread gameThread;
    Image BACKGROUND_IMAGE;
    Player player1;
    Player player2;
    JoyStick joyStick1;
    JoyStick joyStick2;

    GameBoard(){
        try{
            BACKGROUND_IMAGE = ImageIO.read(new File("src/resources/bg.jpeg"));
        } catch (IOException e){
            System.out.println(e.getMessage());
        }
        int[]settings1 = {87,83,65,68};
        joyStick1 = new JoyStick(settings1);
        player1 = new Player(this,joyStick1, new Color(0,255,0),160,270, "right");
        int[]settings2 = {38,40,37,39};
        joyStick2 = new JoyStick(settings2);
        player2 = new Player(this,joyStick2,new Color(255,0,0),980,270, "left");
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setDoubleBuffered(true);
        this.addKeyListener(joyStick1);
        this.addKeyListener(joyStick2);
        this.setFocusable(true);
    }

    public void startGame(){
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run(){

        double drawInterval = 1000000000 / FPS; // 0.0166666 seconds
        double nextDrawTime = System.nanoTime() + drawInterval;

        while(gameThread != null) {
            update();
            repaint();

            try{
                double remainingDrawTime = nextDrawTime - System.nanoTime();
                remainingDrawTime = remainingDrawTime / 1000000;
                Thread.sleep((long) remainingDrawTime);

                nextDrawTime += drawInterval;

                if(remainingDrawTime < 0) {
                    remainingDrawTime = 0;
                }
            } catch(InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public void update() {
        player1.update();
        player2.update();
    }

    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawImage(BACKGROUND_IMAGE,0,0,screenWidth,screenHeight,null);
        player1.draw(g2d);
        player2.draw(g2d);
        g2d.dispose();
    }
}
